<input type="checkbox" class="check-box-id" value="{{ $id }}">
