<div class="table-responsive">
    {{ $dataTable->table([], true) }}
</div>

{{ $dataTable->scripts() }}
