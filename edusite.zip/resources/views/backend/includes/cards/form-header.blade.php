<a class="heading-elements-toggle">
    <i class="la la-ellipsis-h font-medium-3"></i>
</a>
<div class="heading-elements" style="top: 16px">
    <ul class="list-inline mb-0">
        <li>
            <a href="{{ route('backend.' . getModel() . '.index') }}"
                {{-- class="btn bg-primary bg-darken-4 white dropdown-item"> --}}
                class="btn btn-primary btn-glow dropdown-item">
                <i class="fas fa-sign-out-alt"></i> Back
            </a>
        </li>
    </ul>
</div>
