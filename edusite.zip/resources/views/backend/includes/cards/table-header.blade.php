<div class="card-header bg-info white">
    <h4 class="card-title white">
        {{ ucfirst(getModel()) }} : <span id="recourds-count"> {{ $count }}</span>
    </h4>
</div>
