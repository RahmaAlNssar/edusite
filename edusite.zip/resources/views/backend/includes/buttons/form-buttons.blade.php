<div class="form-actions d-flex justify-content-between m-0">
    <button type="reset" class="btn btn-warning" data-dismiss="modal">
        <i class="ft-x"></i> Cancel
    </button>
    <button type="submit" class="btn btn-primary">
        <i class="la la-check-square-o"></i> Save
    </button>
</div>
