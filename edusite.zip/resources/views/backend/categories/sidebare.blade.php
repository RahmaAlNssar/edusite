<div class="sidebar-detached sidebar-left position-relative d-sm-none d-md-block">
    <div class="sidebar position-fixed">
        <div class="card">
            {{-- START INCLUDE THE FORM PAGE --}}
            @include('backend.includes.forms.form-create')
            {{-- END INCLUDE THE FORM PAGE --}}
        </div>
    </div>
</div>
