<div class="partners">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="partners_slider_container">
                    <div class="owl-carousel owl-theme partners_slider">

                        <!-- Partner Item -->
                        <div class="owl-item partner_item"><img
                                src="{{ asset('assets/frontend/images/partner_1.png') }}" alt=""></div>

                        <!-- Partner Item -->
                        <div class="owl-item partner_item"><img
                                src="{{ asset('assets/frontend/images/partner_2.png') }}" alt=""></div>

                        <!-- Partner Item -->
                        <div class="owl-item partner_item"><img
                                src="{{ asset('assets/frontend/images/partner_3.png') }}" alt=""></div>

                        <!-- Partner Item -->
                        <div class="owl-item partner_item"><img
                                src="{{ asset('assets/frontend/images/partner_4.png') }}" alt=""></div>

                        <!-- Partner Item -->
                        <div class="owl-item partner_item"><img
                                src="{{ asset('assets/frontend/images/partner_5.png') }}" alt=""></div>

                        <!-- Partner Item -->
                        <div class="owl-item partner_item"><img
                                src="{{ asset('assets/frontend/images/partner_6.png') }}" alt=""></div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
