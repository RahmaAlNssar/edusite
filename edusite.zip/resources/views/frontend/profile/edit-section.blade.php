<div role="tabpanel" class="tab-pane active" id="courses" aria-expanded="true" aria-labelledby="baseIcon-tab21">
    <div class="row">
        <div class="col-md-12">

            @include('frontend.profile.edit-information')

            @include('frontend.profile.edit-password')

        </div>
    </div>
</div>
