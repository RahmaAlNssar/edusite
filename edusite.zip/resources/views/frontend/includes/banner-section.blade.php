<div class="sidebar_section">
    <div class="sidebar_banner d-flex flex-column align-items-center justify-content-center text-center">
        <div class="sidebar_banner_background"
            style="background-image:url({{ asset('assets/frontend/images/banner_1.jpg') }})">
        </div>
        <div class="sidebar_banner_overlay"></div>
        <div class="sidebar_banner_content">
            <div class="banner_title">Free Book</div>
            <div class="banner_button"><a href="#">download now</a></div>
        </div>
    </div>
</div>
