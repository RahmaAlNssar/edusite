<div class="home">
    <div class="breadcrumbs_container">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="breadcrumbs">
                        <ul>
                            <li><a href="{{ route('/') }}">Home</a></li>
                            {!! $breadcrumb_link !!}

                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
